#include <iostream>
#include "simpleMenu.hpp"

using namespace std;

int main() {
	simpleMenu menu;
}